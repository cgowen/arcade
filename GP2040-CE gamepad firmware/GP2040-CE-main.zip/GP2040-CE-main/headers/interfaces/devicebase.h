#ifndef _DEVICEBASE_H_
#define _DEVICEBASE_H_

class DeviceBase {
    public:
        DeviceBase() {}
        ~DeviceBase() {}

};

#endif
#ifndef _GPGFX_CORE_H_
#define _GPGFX_CORE_H_

#include "GPGFX_types.h"
#include "displaybase.h"

#include "fonts/GP_Font_Basic.h"
#include "fonts/GP_Font_Big.h"
#include "fonts/GP_Font_Standard.h"

#endif
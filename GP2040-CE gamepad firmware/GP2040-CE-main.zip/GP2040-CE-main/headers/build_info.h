/* generate build information (such as stuff auto-included in the .uf2) */
#include "pico/binary_info.h"
#include "pico/binary_info/code.h"

#include "BoardConfig.h"

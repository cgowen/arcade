#ifndef _EXTENSIONS_H_
#define _EXTENSIONS_H_

#include "ExtensionBase.h"
#include "ClassicExtension.h"
#include "DrumExtension.h"
#include "GuitarExtension.h"
#include "NunchuckExtension.h"
#include "TaikoExtension.h"
#include "TurntableExtension.h"

#endif

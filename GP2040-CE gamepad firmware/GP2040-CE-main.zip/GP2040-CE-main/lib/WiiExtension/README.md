# WiiExtension
#
# Written by:
#  Mike Parks
#   <mikepparks@gmail.com>
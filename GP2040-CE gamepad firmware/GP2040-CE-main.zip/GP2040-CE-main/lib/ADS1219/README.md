# ADS1219
#  Ported to BitBangI2C
#
# Ported/Written by:
#  Luke Arntson
#   <arntsonl@Gmail.com>
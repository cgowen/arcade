# GP2040 Configuration for Adafruit KB2040

![Pin Mapping](assets/PinMapping.png)

Basic pin setup for a Raspberry Pi Pico based Adafruit KB2040.

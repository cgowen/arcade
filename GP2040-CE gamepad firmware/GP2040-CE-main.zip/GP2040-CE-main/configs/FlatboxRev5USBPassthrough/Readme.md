# GP2040 Configuration for Flatbox rev5 USB Passthrough

![Flatbox rev5 USB Passthrough](assets/Flatbox-rev5-USB-Passthrough.jpg)

Configuration for the [Flatbox rev5 USB Passthrough](https://github.com/jfedor2/flatbox/tree/master/hardware-rev5), a variant of the [Flatbox Rev 5](https://github.com/jfedor2/flatbox/tree/master/hardware-rev5) design by [jfedor2](https://github.com/jfedor2).

# GP2040 Configuration for the ARC Accessibility Controller

![ARC Accessibility Controller](assets/ARC%20Accessibility%20Controller%201.JPG)

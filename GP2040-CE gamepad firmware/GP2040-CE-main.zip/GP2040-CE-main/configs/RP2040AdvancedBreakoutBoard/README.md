# GP2040 Configuration for the RP2040 Advanced Breakout Board

![RP2040 Advanced Breakout Board](assets/RP2040AdvancedBreakoutBoard.jpg)

Basic pin setup for the RP2040 Advanced Breakout Board.

![Pin Mapping](assets/RP2040AdvancedBreakoutBoard_pinout.png)

# GP2040-CE Configuration for the Reflex CTRL NES Board by MiSTer Addons

![Reflex CTRL NES](https://github.com/misteraddons/Reflex-CTRL/raw/main/Images/nes.png)

Open source replacement PCB for Nintendo NES-004 controllers

Purchase: https://misteraddons.com/products/Reflex-CTRL

GitHub: https://github.com/misteraddons/Reflex-CTRL

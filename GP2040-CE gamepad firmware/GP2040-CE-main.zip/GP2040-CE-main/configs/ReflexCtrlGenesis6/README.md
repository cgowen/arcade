# GP2040-CE Configuration for the Reflex CTRL Genesis 6 Board by MiSTer Addons

![Reflex CTRL Genesis 6](https://github.com/misteraddons/Reflex-CTRL/raw/main/Images/genesis6.png)

Open source replacement PCB for Sega Genesis controllers
* USA 6 button controllers
* Japanese 6 button controller
* Retro-Bit Saturn controller

Purchase: https://misteraddons.com/products/Reflex-CTRL

GitHub: https://github.com/misteraddons/Reflex-CTRL

# GP2040-CE Configuration for the Reflex CTRL SNES Board by MiSTer Addons

![Reflex CTRL SNES](https://github.com/misteraddons/Reflex-CTRL/raw/main/Images/snes.png)

Open source replacement PCB for Nintendo SNES-001 controllers

Purchase: https://misteraddons.com/products/Reflex-CTRL

GitHub: https://github.com/misteraddons/Reflex-CTRL

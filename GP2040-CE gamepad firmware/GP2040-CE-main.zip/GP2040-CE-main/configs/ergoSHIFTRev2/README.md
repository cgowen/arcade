# GP2040 Configuration for the ergoSHIFT Rev.2

![ergoSHIFT Rev.2](./assets/ergoSHIFT-rev2-bare1.jpg)

Configuration for the [ergoSHIFT Rev.2](https://github.com/mizma/ergoSHIFT/tree/main/hardware-rev2), a 4+11 button lever-less
arcade controller designed by [mizma](https://github.com/mizma/).

## Button mapping

![ergoSHIFT Rev.2 button mapping](./assets/ergoSHIFT-rev2-button-mapping.jpg)
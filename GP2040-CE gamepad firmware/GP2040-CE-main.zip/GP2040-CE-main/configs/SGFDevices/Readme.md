# GP2040 Configuration for SGF Devices controllers

![SGF Logo](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/SGFDevices/assets/SGF_Logo.png)

Configuration for [SGF Devices All Button Controllers](https://sgfdevices.com/collections/controllers).  

![SGF Controller](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/SGFDevices/assets/SGF_Controller.png)
![SGF Layout](https://github.com/OpenStickCommunity/GP2040-CE/blob/main/configs/SGFDevices/assets/SGF_Layout.png)

# GP2040 Configuration for Sparkfun Pro Micro - RP2040

![Pin Mapping](assets/Liatris.png)

Basic pin setup for a stock [Liatris](https://splitkb.com/products/liatris).

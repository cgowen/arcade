# GP2040 Configuration for Flatbox rev5

![Flatbox rev5](assets/Flatbox-rev5.jpg)

Configuration for the [Flatbox rev5](https://github.com/jfedor2/flatbox/tree/master/hardware-rev5), a variant of the [Flatbox](https://github.com/jfedor2/flatbox) design by [jfedor2](https://github.com/jfedor2). This revision uses an RP2040-Zero board.

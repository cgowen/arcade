# GP2040 Configuration for the Stress Fightpad

![Stress Fightpad](assets/stress-00.jpg)

Configuration for the [Stress Fightpad](https://github.com/GroooveBob/Stress). Configuration uses the same pinout as the Waveshare RP2040 Zero.


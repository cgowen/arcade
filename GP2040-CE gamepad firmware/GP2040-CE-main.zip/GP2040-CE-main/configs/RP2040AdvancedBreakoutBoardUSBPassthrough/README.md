# GP2040 Configuration for the RP2040 Advanced Breakout Board USB Passthrough Edition

![RP2040 Advanced Breakout Board - USB Passthrough](assets/RP2040 Advanced Breakout Board - Passthrough.jpg)

Basic pin setup for the RP2040 Advanced Breakout Board.

![Pin Mapping](assets/RP2040AdvancedBreakoutBoard_pinout.png)

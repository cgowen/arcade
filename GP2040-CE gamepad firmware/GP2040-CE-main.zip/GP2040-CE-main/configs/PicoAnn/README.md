# GP2040-CE Configuration for PicoAnn firmware boards

![Pin Mapping](assets/PinMapping_PicoAnn.png)

Basic pin setup for boards that were running PicoAnn firmware like the Pico Advanced Breakout Board v3.0.

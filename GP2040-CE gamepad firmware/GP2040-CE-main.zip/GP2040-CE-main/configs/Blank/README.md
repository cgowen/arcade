# GP2040 Blank Configuration

This is a blank configuration file.  It will not map any pins by defualt.  

This is good for builders who want to setup from scratch or those that want to experiment.  It is recommended to the the `force_webconfig.uf2` to get into web-config so you can set a `start` button.
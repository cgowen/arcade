# GP2040 Configuration for the Mavercade Keebfighter

![Mavercade logo](assets/Mavercade-logo.png)

Configuration for the [Mavercade Keebfighter S3+ and S4+](https://mavercade.com/collections/mavercade-fightsticks). 

Mavercade Keebfighter S3+ - Check it out [here](https://mavercade.com/products/mavercade-keebfighter-s3)
Mavercade Keebfighter S4+ - Check it out [here](https://mavercade.com/products/mavercade-keebfighter-s4)
![Mavercade Keebfighter S3+ and S4+](assets/Rev2_config_pic.jpg)
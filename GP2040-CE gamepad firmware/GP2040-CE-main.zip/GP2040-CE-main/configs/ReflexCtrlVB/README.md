# GP2040-CE Configuration for the Reflex CTRL Virtual Boy Board by MiSTer Addons

![Reflex CTRL Virtual Boy](https://github.com/misteraddons/Reflex-CTRL/raw/main/Images/vb.png)

Open source replacement PCB for Nintendo Virtual Boy controllers

Note: Do not connect any packs to the controller. The USB cable powers the controller.

Purchase: https://misteraddons.com/products/Reflex-CTRL

GitHub: https://github.com/misteraddons/Reflex-CTRL

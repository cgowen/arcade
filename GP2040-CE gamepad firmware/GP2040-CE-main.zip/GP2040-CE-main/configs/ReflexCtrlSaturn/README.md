# GP2040-CE Configuration for the Reflex CTRL Saturn Board by MiSTer Addons

![Reflex CTRL Saturn](https://github.com/misteraddons/Reflex-CTRL/raw/main/Images/saturn.png)

Open source replacement PCB for Sega Saturn controllers
* USA Model 2 controller
* Japanese controller
* Retro-Bit Saturn controller

Purchase: https://misteraddons.com/products/Reflex-CTRL

GitHub: https://github.com/misteraddons/Reflex-CTRL

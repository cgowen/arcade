# GP2040 Configuration for Sparkfun Pro Micro - RP2040

![Pin Mapping](assets/SparkFunProMicroRP2040.png)

Basic pin setup for a stock [Sparkfun Pro Micro - RP2040](https://www.sparkfun.com/products/18288).

The pin layout is designed to be a drop in replacement for the [Daemonbite Arcade encoder](https://github.com/MickGyver/DaemonBite-Arcade-Encoder).

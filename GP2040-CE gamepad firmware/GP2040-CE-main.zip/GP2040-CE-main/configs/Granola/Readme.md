# GP2040 Configuration for Granola Arcade controllers

![Granola Arcade Logo](assets/granola-logo.png)

Configuration for [Granola Arcade](https://granola.games) controllers.
